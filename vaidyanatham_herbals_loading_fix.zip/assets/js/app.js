/* Vaidyanatham Herbals — extracted JavaScript. Original inline script order preserved. */

/* ===== Original inline script 01; id="tour-navigation-premium-script" ===== */
(function(){
  'use strict';
  var section=document.getElementById('tourNavigation');
  var message=document.getElementById('tourPlannerMessage');
  if(!section || !message) return;

  var timer=0;
  var observer;

  function showMessage(){
    clearTimeout(timer);
    message.classList.add('show');
    message.setAttribute('aria-hidden','false');
    timer=setTimeout(function(){
      message.classList.remove('show');
      message.setAttribute('aria-hidden','true');
    },5000);
  }

  if('IntersectionObserver' in window){
    observer=new IntersectionObserver(function(entries){
      entries.forEach(function(entry){
        if(entry.isIntersecting && entry.intersectionRatio >= .25){
          showMessage();
          observer.unobserve(section);
        }
      });
    },{threshold:[.25]});
    observer.observe(section);
  }else{
    var fired=false;
    window.addEventListener('scroll',function(){
      if(fired)return;
      var r=section.getBoundingClientRect();
      if(r.top < window.innerHeight*.75 && r.bottom > 0){
        fired=true;
        showMessage();
      }
    },{passive:true});
  }
})();


/* ===== Original inline script 02; no attributes ===== */
let cart=[];const E=id=>document.getElementById(id);const esc=v=>String(v).replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]));
function toast(m){let t=E('vaToast');if(!t){t=document.createElement('div');t.id='vaToast';t.className='vaToast';document.body.appendChild(t)}t.textContent=m;t.classList.add('show');clearTimeout(window.tt);window.tt=setTimeout(()=>t.classList.remove('show'),2200)}
function addCart(n,p){cart.push({name:n,price:+p||0});if(E('count'))E('count').textContent=cart.length;toast(n+' added to cart')}
function showCart(){let x=E('cartItems');if(!x)return;if(!cart.length){x.innerHTML='<div class="cartEmpty"><p>Your cart is empty.</p><button class="btn ghost" type="button" onclick="closeModal()">Continue browsing</button></div>';}else{const priced=cart.filter(v=>v.price>0);const total=priced.reduce((a,v)=>a+v.price,0);x.innerHTML=cart.map((v,i)=>'<div class="cartLine"><div class="cartLineInfo"><b>'+(i+1)+'. '+esc(v.name)+'</b><span>'+(v.price>0?'₹'+v.price.toLocaleString('en-IN'):'Price on request')+'</span></div><button class="removeCart" type="button" onclick="removeCartItem('+i+')" aria-label="Remove '+esc(v.name)+' from cart" title="Remove item">Remove</button></div>').join('')+'<div class="cartTotal"><span>Total</span><b>'+(total?'₹'+total.toLocaleString('en-IN'):'Price on request')+'</b></div>'}E('modal').style.display='flex'}
function removeCartItem(i){if(i<0||i>=cart.length)return;const removed=cart.splice(i,1)[0];if(E('count'))E('count').textContent=cart.length;showCart();toast(removed.name+' removed from cart')}
function checkoutCart(){if(!cart.length){toast('Your cart is empty.');return}const m='Hello Vaidyanatham, I would like to order:\n'+cart.map((v,i)=>(i+1)+'. '+v.name+' — '+(v.price>0?'₹'+v.price:'Price on request')).join('\n')+'\nTotal: '+(cart.some(v=>v.price===0)?'Price on request':'₹'+cart.reduce((a,v)=>a+v.price,0));openWA(m)}
const parents={story:'storyDrop',expectations:'storyDrop',usp:'uspDrop',care:'careDrop',departments:'departmentsDrop',diseases:'diseasesDrop',diseaseRecords:'diseasesDrop',trust:'diseasesDrop',packages:'packagesDrop',herbs:'herbsDrop',doctor:'doctorDrop',premiumProduct:'shopDrop',shop:'shopDrop',consult:'consultDrop',booking:'consultDrop'};
function openDrop(id){const d=E(id);if(!d)return;document.querySelectorAll('.megaDrop[open]').forEach(v=>{if(v!==d)v.open=false});d.open=true}
const mobileTargets={storyDrop:'story',uspDrop:'usp',careDrop:'care',departmentsDrop:'departments',diseasesDrop:'diseases',packagesDrop:'packages',herbsDrop:'herbs',doctorDrop:'doctor',shopDrop:'shop',consultDrop:'booking',keralaDrop:'kerala'};
function enquirePackage(name,days){openWA('Hello Vaidyanatham, I would like to enquire about the '+name+' wellness package ('+days+'). Please advise suitability, therapies, precautions, duration and current pricing.')}
function openExploreWellness(){
  const d=E('shopDrop');
  if(!d)return;
  document.querySelectorAll('.megaDrop[open]').forEach(v=>{if(v!==d)v.open=false});
  d.open=true;
  document.querySelectorAll('.heroBtns .btn').forEach(v=>v.classList.remove('is-active'));
  const btn=document.querySelector('.heroBtns .btn.primary');
  if(btn){btn.classList.add('is-active');btn.setAttribute('aria-current','true');}
  const target=E('premiumProduct')||E('shop')||d;
  if(target)setTimeout(()=>target.scrollIntoView({behavior:'smooth',block:'start'}),80);
}
function openConsult(){openDrop('consultDrop');setTimeout(()=>E('booking')?.scrollIntoView({behavior:'smooth',block:'start'}),120)}
function navHash(h){const id=h.slice(1);if(parents[id])openDrop(parents[id]);setTimeout(()=>E(id)?.scrollIntoView({behavior:'smooth',block:'start'}),parents[id]?140:50)}
document.addEventListener('click',e=>{const a=e.target.closest('a[href^="#"]');if(a&&a.getAttribute('href').length>1){e.preventDefault();history.replaceState(null,'',a.getAttribute('href'));navHash(a.getAttribute('href'))}})
function closeModal(){if(E('modal'))E('modal').style.display='none'}
function toastLink(message,url){
  let t=E('vaToast');
  if(!t){t=document.createElement('div');t.id='vaToast';t.className='vaToast';document.body.appendChild(t)}
  t.replaceChildren(document.createTextNode(message+' '));
  const a=document.createElement('a');
  a.href=url;a.target='_blank';a.rel='noopener noreferrer';a.textContent='Continue to WhatsApp';
  a.style.cssText='color:#fff;text-decoration:underline;font-weight:800;margin-left:5px';
  t.appendChild(a);t.classList.add('show');clearTimeout(window.tt);
  window.tt=setTimeout(()=>t.classList.remove('show'),7000);
}
function openWA(text,target='918921669537'){
  const url='https://wa.me/'+target+'?text='+encodeURIComponent(text);
  const win=window.open(url,'_blank');
  if(win){try{win.opener=null}catch(_){}}
  else toastLink('Your browser blocked the new tab.',url);
  return !!win;
}
async function submitConsult(){
  const n=(E('name')?.value||'').trim(),
        p=(E('phone')?.value||'').replace(/\D/g,''),
        ph=E('physician')?.value||'',
        d=E('department')?.value||'',
        dt=E('date')?.value||'Not selected',
        tm=E('time')?.value||'Not selected',
        payment=E('payment')?.files?.[0]||null;
  if(!n||!p){toast('Please enter your name and mobile number.');return}
  if(p.length<10){toast('Please enter a valid mobile number.');return}
  if(!ph||ph==='Choose physician'){toast('Please choose a physician.');return}
  if(!d||d==='Choose department'){toast('Please choose a department.');return}
  if(!payment){toast('Please attach your payment screenshot before submitting.');return}

  const target=ph==='Dr. Lekshmy A'?'919061620696':'918921669537';
  const message='Hello '+ph+', I would like to request a consultation.\n\nName: '+n+'\nMobile: '+p+'\nPhysician: '+ph+'\nDepartment: '+d+'\nDate: '+dt+'\nTime: '+tm+'\nConsultation fee: ₹450\nPayment screenshot attached.';
  const shareFile=new File([payment], 'Vaidyanatham-Payment-Screenshot.'+(payment.name.split('.').pop()||'jpg'), {type:payment.type||'image/jpeg'});

  // WhatsApp wa.me cannot receive a local file attachment through a URL.
  // On supported mobile browsers, Web Share sends the actual image to the
  // system share sheet; selecting WhatsApp preserves the attachment.
  if(navigator.share && (!navigator.canShare || navigator.canShare({files:[shareFile]}))){
    try{
      await navigator.share({title:'Vaidyanatham Consultation Booking',text:message,files:[shareFile]});
      toast('Booking details and payment screenshot shared successfully.');
      return;
    }catch(err){
      if(err && err.name==='AbortError'){toast('Sharing cancelled. Your form details are still here.');return}
    }
  }

  openWA(message,target);
  toast('WhatsApp opened. Please attach the selected payment screenshot manually on this device.');
}

let vaAlbumIndex=0;
function albumRender(nextIndex, animate=true){
  const cards=[...document.querySelectorAll('.vaAlbumCard')];
  if(!cards.length)return;
  vaAlbumIndex=(nextIndex+cards.length)%cards.length;
  cards.forEach((card,i)=>{
    card.classList.remove('is-active','is-next','is-next2','is-prev','album-flip');
    const rel=(i-vaAlbumIndex+cards.length)%cards.length;
    if(rel===0)card.classList.add('is-active');
    else if(rel===1)card.classList.add('is-next');
    else if(rel===2)card.classList.add('is-next2');
    else if(rel===cards.length-1)card.classList.add('is-prev');
  });
  const active=cards[vaAlbumIndex];
  if(animate){
    void active.offsetWidth;
    active.classList.add('album-flip');
  }
  const title=active.querySelector('span')?.textContent||'Vaidyanatham';
  if(E('vaAlbumTitle'))E('vaAlbumTitle').textContent=title;
  if(E('vaAlbumCount'))E('vaAlbumCount').textContent=(vaAlbumIndex+1)+' / '+cards.length;
}
function albumNext(index){
  albumRender(typeof index==='number'?index:vaAlbumIndex+1,true);
}
function albumPrev(){albumRender(vaAlbumIndex-1,true)}

function toggleMobileMenu(){const m=E('mobileMenu');if(!m)return;const o=m.classList.toggle('open');m.setAttribute('aria-hidden',o?'false':'true');document.body.classList.toggle('menu-open',o)}
function mobileOpen(id){toggleMobileMenu();openDrop(id);const target=mobileTargets[id];if(target)setTimeout(()=>E(target)?.scrollIntoView({behavior:'smooth',block:'start'}),160)}
function setSiteLanguage(v){const c=document.querySelector('.goog-te-combo');if(c){c.value=v;c.dispatchEvent(new Event('change'))}}
function googleTranslateElementInit(){new google.translate.TranslateElement({pageLanguage:'en',includedLanguages:'en,ml,hi,ta,te,kn,fr,ru,ar,de,es,ja',autoDisplay:false},'google_translate_element')}

async function updateConsultationFX(){
  const out=E('consultFeeFx'), stamp=E('consultFeeFxDate');
  if(!out)return;
  const fallback={USD:0.01044,GBP:0.007891};
  let rates=fallback, sourceDate='fallback';
  try{
    const controller=new AbortController();
    const timeoutId=setTimeout(()=>controller.abort(),5000);
    try{
      const r=await fetch('https://open.er-api.com/v6/latest/INR',{cache:'no-store',signal:controller.signal});
      if(!r.ok)throw new Error('FX request failed');
      const j=await r.json();
      const usdRate=Number(j?.rates?.USD), gbpRate=Number(j?.rates?.GBP);
      if(Number.isFinite(usdRate)&&usdRate>0&&Number.isFinite(gbpRate)&&gbpRate>0){
        rates={USD:usdRate,GBP:gbpRate};
        sourceDate=j.time_last_update_utc?new Date(j.time_last_update_utc).toISOString().slice(0,10):new Date().toISOString().slice(0,10);
      }
    }finally{
      clearTimeout(timeoutId);
    }
  }catch(_){}
  const usd=(450*rates.USD).toFixed(2), gbp=(450*rates.GBP).toFixed(2);
  out.textContent='≈ $'+usd+' USD • £'+gbp+' GBP';
  if(stamp)stamp.textContent=(sourceDate==='fallback'?'Daily mid-market conversion • fallback rate':'Daily mid-market conversion • '+sourceDate+' • updates when the page loads');
}
updateConsultationFX();
albumRender(0,false);
(()=>{const e=document.querySelector('.va-counter');if(!e)return;const target=+(e.dataset.count||5000);let done=false;const run=()=>{if(done)return;done=true;const t=performance.now();const f=n=>{const p=Math.min(1,(n-t)/1500),q=1-Math.pow(1-p,3);e.textContent=Math.floor(target*q).toLocaleString('en-IN')+'+';if(p<1)requestAnimationFrame(f)};requestAnimationFrame(f)};if('IntersectionObserver'in window)new IntersectionObserver(a=>a.forEach(x=>x.isIntersecting&&run()),{threshold:.4}).observe(e);else run()})();
const diseaseData=[["Intervertebral Disc Prolapse","Ayurvedic correlation varies by presentation","3–6 weeks"],["Peptic Ulcer","Amlapitta / Parinama Shoola correlations may apply","30–90 days"],["Obesity","Medoroga correlation may apply","Variable / long-term"],["Viral Fevers","Jwara","3–14 days"],["Mumps","Kaphaja-type clinical correlation varies","7–10 days"],["Fungal Infections","Dadru / Kandu-type correlations may apply","3–4 weeks"],["Hepatitis A / C","Kamala / Yakrit disorders may be considered","1–4 weeks"],["Hepatitis B","Kamala / Yakrit disorders may be considered","3–9 weeks"],["Malaria","Vishama Jwara correlation may apply","2–3 weeks"],["Amoebiasis","Grahani / Atisara correlations may apply","20 days–3 months"],["Cirrhosis of Liver","Yakrit Vikara","Up to 6 months"],["Gallbladder Calculi","Ashmari-type correlation varies","6 weeks–6 months"],["Pancreatitis","Agni / Aamashaya assessment required","~4 weeks chronic"],["Diabetes Mellitus","Prameha / Madhumeha","Long-term; no fixed duration"],["Hypothyroidism","Dhatvagni / metabolic assessment varies","4–8 weeks"],["Hyperthyroidism","Metabolic assessment varies","4–6 weeks"],["Rheumatoid Arthritis","Amavata","At least 2–3 months"],["Systemic Lupus Erythematosus","Autoimmune presentation requires individual assessment","~3–8 months"],["Systemic Hypertension","Rakta-gata / Vyana Vayu assessment varies","~2–3 weeks response"],["Hypercholesterolemia","Medodushti / Medovaha Srotas assessment","2–3 months"],["Cervical Spondylosis","Manyastambha / Greeva assessment","3–4 months OPD; 2–3 weeks IP"],["Osteoarthritis","Sandhivata","2–6 months medication; 2–3 weeks treatment"],["Osteoporosis","Asthi Kshaya","1–2 months"],["Coronary Artery Disease","Hridroga","~6–8 months"],["Bronchial Asthma","Tamaka Shwasa","~3 months"],["Cardiac Asthma","Hridroga / Shwasa assessment","No fixed duration"],["Allergic Respiratory Disorders","Pratishyaya / Shwasa correlations vary","4–6 weeks"],["Anemia","Pandu","2–3 weeks nutritional; longer in chronic causes"],["Urinary Tract Infection","Mutrakrichra","10 days–3 weeks"],["Nephrotic Syndrome","Mutra / Udakavaha Srotas assessment","1–2 weeks acute; 1–2 months chronic"],["Renal Failure","Vrikka Vikara","2–3 months minimum; longer chronic"],["Renal Calculus","Ashmari","6–12 weeks; recurrence care longer"],["Migraine","Suryavarta / Ardhavabhedaka correlations","1–6 months; variable"],["Sinusitis","Pinasa","1–3 months"],["Epilepsy","Apasmara","4–6 months selected presentations"],["Psoriasis","Kushtha / Kitibha-type correlation","3–5 months severe chronic"],["Urticaria","Sheetapitta / Udarda","~3 weeks"],["Eczema","Vicharchika","At least ~3 months in some chronic cases"],["Herpes","Visarpa-type correlation varies","~3 weeks; neuralgia longer"],["Hemorrhoids","Arshas","4–6 weeks; longer for substantial reduction"],["Filariasis","Shleepada","3–6 weeks acute"],["Benign Prostate Hyperplasia","Mutraghata / prostate assessment","~1 month symptomatic"],["Hemangioma","Rakta-related assessment varies","~2 weeks response; ~1 month substantial"],["Tennis Elbow","Snayugata / Sandhi assessment","3–6 months"],["Varicose Veins","Siragranthi / Siravyadha assessment varies","~3 weeks symptomatic"],["Carpal Tunnel Syndrome","Nadi / Snayu compression assessment","~3 weeks"],["Periarthritis","Amsa Sandhi-related assessment","~1 month; longer in diabetes"],["Tenosynovitis","Snayu / Kandara assessment","~2 weeks"],["Inguinal Hernia","Antra Vriddhi / structural assessment","No fixed duration"],["Varicose Ulcer","Dushta Vrana","6–8 weeks"],["Cellulitis","Visarpa / inflammatory correlation varies","~7 days"],["Abscess","Vidradhi","Variable; drainage may be required"],["Warts","Charmakeela","No fixed duration"],["Diabetic Gangrene","Dushta Vrana / vascular assessment","2–3 months in cited material"],["Thromboangiitis Obliterans (TAO)","Vata/Rakta vascular assessment","2–6 months"],["Non-healing Ulcers","Dushta Vrana","3–6 weeks"],["Corns","Kadara","~3 weeks"],["Scoliosis","Spinal deformity assessment; classical correlation varies","~3 months"]];
const diseaseTarget=document.getElementById('diseaseRecords');
if(diseaseTarget && !diseaseTarget.children.length) diseaseTarget.innerHTML=diseaseData.map(d=>`<article class="diseaseRecord"><div class="modern">${d[0]}</div><small class="ayu">${d[1]}</small><div class="duration"><b>Expected time duration:</b> ${d[2]}</div></article>`).join('');
(()=>{const t=document.querySelector('.va-test-track');if(t)t.innerHTML+=t.innerHTML;const d=E('date');if(d){const now=new Date();const y=now.getFullYear(),m=String(now.getMonth()+1).padStart(2,'0'),day=String(now.getDate()).padStart(2,'0');d.min=y+'-'+m+'-'+day}})();
E('modal')?.addEventListener('click',e=>{if(e.target.id==='modal')closeModal()});
document.addEventListener('keydown',e=>{if(e.key==='Escape'){closeModal();E('mobileMenu')?.classList.remove('open');document.body.classList.remove('menu-open')}if((e.key==='Enter'||e.key===' ')&&e.target?.id==='cartButton'){e.preventDefault();showCart()}});

// Ripple feedback for the two requested hero CTAs only
document.querySelectorAll('.rippleBtn').forEach(btn=>btn.addEventListener('pointerdown',e=>{const r=btn.getBoundingClientRect();btn.style.setProperty('--rx',(e.clientX-r.left)+'px');btn.style.setProperty('--ry',(e.clientY-r.top)+'px');btn.classList.remove('ripple-active');void btn.offsetWidth;btn.classList.add('ripple-active')}));


/* ===== Original inline script 03; id="vaidyanatham-relax-script" ===== */
(function(){
  const btn=document.getElementById("vaidyanathamRelax");
  if(!btn) return;

  const brand=btn.querySelector(".vr-brand");
  const word=btn.querySelector(".vr-word");
  const number=btn.querySelector(".vr-number");

  const IDLE_SIZE=58;
  const MIN_SIZE=104;
  const MAX_SIZE=180;
  const phases=[
    {label:"BREATHE IN",seconds:4},
    {label:"HOLD",seconds:2},
    {label:"BREATHE OUT",seconds:6}
  ];

  let running=false, phase=0, phaseStart=0, duration=0, raf=0;
  let dragging=false, didDrag=false, dragPointerX=0, dragPointerY=0, dragOriginLeft=0, dragOriginTop=0;

  function ease(t){return t*t*(3-2*t)}
  function setSize(size){
    const safeSize=Math.max(IDLE_SIZE,Math.min(MAX_SIZE,size));
    const scale=safeSize/IDLE_SIZE;
    btn.style.setProperty('--va-relax-scale',scale.toFixed(3));
  }
  function setIdleText(){
    brand.textContent="vaidyanatham's";
    word.textContent="RELAX";
    number.textContent="BUTTON";
  }

  function beginPhase(){
    const p=phases[phase];
    duration=p.seconds*1000;
    phaseStart=performance.now();
    word.textContent=p.label;
    number.textContent=p.seconds;
    setSize(phase===0 ? MIN_SIZE : MAX_SIZE);
    raf=requestAnimationFrame(animate);
  }

  function animate(now){
    if(!running)return;
    const elapsed=Math.min(now-phaseStart,duration);
    const progress=elapsed/duration;

    if(phase===0){
      setSize(MIN_SIZE+(MAX_SIZE-MIN_SIZE)*ease(progress));
    }else if(phase===1){
      setSize(MAX_SIZE);
    }else{
      setSize(MAX_SIZE-(MAX_SIZE-MIN_SIZE)*ease(progress));
    }

    number.textContent=Math.max(1,Math.ceil((duration-elapsed)/1000));

    if(elapsed>=duration){
      phase=(phase+1)%3;
      beginPhase();
      return;
    }
    raf=requestAnimationFrame(animate);
  }

  function start(){
    if(running)return;
    running=true;
    phase=0;
    btn.classList.remove("idle");
    btn.classList.add("breathing");
    beginPhase();
  }

  function stop(){
    running=false;
    cancelAnimationFrame(raf);
    phase=0;
    btn.classList.remove("breathing");
    btn.classList.add("idle");
    setSize(IDLE_SIZE);
    setIdleText();
  }

  btn.addEventListener("click",function(){
    if(didDrag)return;
    running ? stop() : start();
  });

  /* Manual drag only. It never moves automatically. */
  btn.addEventListener("pointerdown",function(e){
    dragging=true;
    didDrag=false;
    btn.setPointerCapture(e.pointerId);
    const r=btn.getBoundingClientRect();
    const scale=Math.max(.5,parseFloat(getComputedStyle(btn).getPropertyValue('--va-relax-scale'))||1);
    dragOriginLeft=r.left+(r.width-IDLE_SIZE)/2;
    dragOriginTop=r.top+(r.height-IDLE_SIZE)/2;
    dragPointerX=e.clientX;
    dragPointerY=e.clientY;
  });

  btn.addEventListener("pointermove",function(e){
    if(!dragging)return;
    const dx=e.clientX-dragPointerX;
    const dy=e.clientY-dragPointerY;
    const x=Math.max(4,Math.min(innerWidth-IDLE_SIZE-4,dragOriginLeft+dx));
    const y=Math.max(4,Math.min(innerHeight-IDLE_SIZE-4,dragOriginTop+dy));
    if(Math.abs(dx)>3 || Math.abs(dy)>3) didDrag=true;
    btn.style.setProperty('--va-relax-left',x+'px');
    btn.style.setProperty('--va-relax-top',y+'px');
    btn.style.setProperty('--va-relax-right','auto');
  });

  function endDrag(){
    dragging=false;
    if(didDrag)setTimeout(function(){didDrag=false},60);
  }
  btn.addEventListener("pointerup",endDrag);
  btn.addEventListener("pointercancel",endDrag);

  setSize(IDLE_SIZE);
  setIdleText();
})();


/* ===== Original inline script 04; id="user-final-navigation-script" ===== */
(function(){
  const topBtn=document.getElementById('vaBackTop');
  if(!topBtn)return;
  function update(){topBtn.classList.toggle('show',window.scrollY>260)}
  topBtn.addEventListener('click',function(){
    const target=document.getElementById('top')||document.body;
    target.scrollIntoView({behavior:'smooth',block:'start'});
  });
  window.addEventListener('scroll',update,{passive:true});
  update();
})();


/* ===== Original inline script 05; id="premium-scroll-load-script" ===== */
(function(){
  'use strict';
  var root=document.documentElement;
  root.classList.add('va-preload');

  function reveal(){
    root.classList.remove('va-preload');
  }

  if(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches){
    reveal();
  }else if(document.readyState==='loading'){
    document.addEventListener('DOMContentLoaded',function(){
      requestAnimationFrame(function(){
        requestAnimationFrame(reveal);
      });
    },{once:true});
  }else{
    requestAnimationFrame(reveal);
  }

  /* Wheel and touch scrolling remain fully native. Existing navigation code
     handles anchor targets and uses smooth programmatic scrolling. */
})();


/* ===== Original inline script 06; id="final-upgrade-script" ===== */
(function(){
  var finished = false;
  function finishLoading(){
    if(finished)return;
    finished=true;
    var screen=document.getElementById('vaLoadingScreen');
    document.body.classList.remove('page-loading');
    document.documentElement.classList.remove('va-preload');
    if(screen){
      screen.classList.add('is-hidden');
      setTimeout(function(){if(screen.parentNode)screen.remove();},420);
    }
  }
  /* Do not wait for window.load: third-party scripts and network requests may stall. */
  if(document.readyState==='loading'){
    document.addEventListener('DOMContentLoaded',function(){
      setTimeout(finishLoading,450);
    },{once:true});
  }else{
    setTimeout(finishLoading,450);
  }
  /* Absolute failsafe, even if DOMContentLoaded or another script misbehaves. */
  setTimeout(finishLoading,2200);

  var field=document.getElementById('presentingComplaints');
  var counter=document.getElementById('complaintsCounter');
  if(field&&counter){
    var update=function(){counter.textContent=field.value.length+' / 1000';};
    field.addEventListener('input',update); update();
  }
})();

/* Load Google Translate after its callback has been defined. */
(function () {
  var src = 'https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit';
  if (document.querySelector('script[src="' + src + '"]')) return;
  var script = document.createElement('script');
  script.src = src;
  script.async = true;
  document.head.appendChild(script);
})();
