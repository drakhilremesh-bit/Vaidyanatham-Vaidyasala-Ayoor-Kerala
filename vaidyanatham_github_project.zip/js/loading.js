/* Vaidyanatham loading-screen controller.
   Does not wait for window.load or third-party scripts. */
(function () {
  'use strict';
  var finished = false;
  function finishLoading() {
    if (finished) return;
    finished = true;
    var screen = document.getElementById('vaLoadingScreen');
    if (document.body) document.body.classList.remove('page-loading');
    if (document.documentElement) document.documentElement.classList.remove('va-preload');
    if (screen) {
      screen.classList.add('is-hidden');
      window.setTimeout(function () {
        if (screen.parentNode) screen.parentNode.removeChild(screen);
      }, 420);
    }
  }
  function scheduleReveal() {
    window.setTimeout(finishLoading, 350);
  }
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', scheduleReveal, { once: true });
  } else {
    scheduleReveal();
  }
  window.setTimeout(finishLoading, 2200);
})();
