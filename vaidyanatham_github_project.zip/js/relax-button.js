/* Extracted from uploaded website; classic script to preserve global onclick handlers. */
(function(){
  const btn=document.getElementById("vaidyanathamRelax");
  if(!btn) return;

  const brand=btn.querySelector(".vr-brand");
  const word=btn.querySelector(".vr-word");
  const number=btn.querySelector(".vr-number");

  const IDLE_SIZE=58;
  const MIN_SIZE=104;
  const MAX_SIZE=180;
  const phases=[
    {label:"BREATHE IN",seconds:4},
    {label:"HOLD",seconds:2},
    {label:"BREATHE OUT",seconds:6}
  ];

  let running=false, phase=0, phaseStart=0, duration=0, raf=0;
  let dragging=false, didDrag=false, offsetX=0, offsetY=0;

  function ease(t){return t*t*(3-2*t)}
  function setSize(size){
    const safeSize=Math.max(IDLE_SIZE,Math.min(MAX_SIZE,size));
    btn.style.setProperty('--va-relax-size',safeSize+'px');
  }
  function setIdleText(){
    brand.textContent="vaidyanatham's";
    word.textContent="RELAX";
    number.textContent="BUTTON";
  }

  function beginPhase(){
    const p=phases[phase];
    duration=p.seconds*1000;
    phaseStart=performance.now();
    word.textContent=p.label;
    number.textContent=p.seconds;
    setSize(phase===0 ? MIN_SIZE : MAX_SIZE);
    raf=requestAnimationFrame(animate);
  }

  function animate(now){
    if(!running)return;
    const elapsed=Math.min(now-phaseStart,duration);
    const progress=elapsed/duration;

    if(phase===0){
      setSize(MIN_SIZE+(MAX_SIZE-MIN_SIZE)*ease(progress));
    }else if(phase===1){
      setSize(MAX_SIZE);
    }else{
      setSize(MAX_SIZE-(MAX_SIZE-MIN_SIZE)*ease(progress));
    }

    number.textContent=Math.max(1,Math.ceil((duration-elapsed)/1000));

    if(elapsed>=duration){
      phase=(phase+1)%3;
      beginPhase();
      return;
    }
    raf=requestAnimationFrame(animate);
  }

  function start(){
    if(running)return;
    running=true;
    phase=0;
    btn.classList.remove("idle");
    btn.classList.add("breathing");
    beginPhase();
  }

  function stop(){
    running=false;
    cancelAnimationFrame(raf);
    phase=0;
    btn.classList.remove("breathing");
    btn.classList.add("idle");
    setSize(IDLE_SIZE);
    setIdleText();
  }

  btn.addEventListener("click",function(){
    if(didDrag)return;
    running ? stop() : start();
  });

  /* Manual drag only. It never moves automatically. */
  btn.addEventListener("pointerdown",function(e){
    dragging=true;
    didDrag=false;
    btn.setPointerCapture(e.pointerId);
    const r=btn.getBoundingClientRect();
    offsetX=e.clientX-r.left;
    offsetY=e.clientY-r.top;
  });

  btn.addEventListener("pointermove",function(e){
    if(!dragging)return;
    const rect=btn.getBoundingClientRect();
    const size=Math.max(1,rect.width);
    const x=Math.max(4,Math.min(innerWidth-size-4,e.clientX-offsetX));
    const y=Math.max(4,Math.min(innerHeight-size-4,e.clientY-offsetY));
    if(Math.abs(x-rect.left)>3 || Math.abs(y-rect.top)>3) didDrag=true;
    btn.style.setProperty('--va-relax-left',x+'px');
    btn.style.setProperty('--va-relax-top',y+'px');
    btn.style.setProperty('--va-relax-right','auto');
  });

  function endDrag(){
    dragging=false;
    if(didDrag)setTimeout(function(){didDrag=false},60);
  }
  btn.addEventListener("pointerup",endDrag);
  btn.addEventListener("pointercancel",endDrag);

  setSize(IDLE_SIZE);
  setIdleText();
})();
