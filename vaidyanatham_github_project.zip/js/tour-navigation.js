/* Extracted from uploaded website; classic script to preserve global onclick handlers. */
(function(){
  'use strict';
  var section=document.getElementById('tourNavigation');
  var message=document.getElementById('tourPlannerMessage');
  if(!section || !message) return;

  var timer=0;
  var observer;

  function showMessage(){
    clearTimeout(timer);
    message.classList.add('show');
    message.setAttribute('aria-hidden','false');
    timer=setTimeout(function(){
      message.classList.remove('show');
      message.setAttribute('aria-hidden','true');
    },5000);
  }

  if('IntersectionObserver' in window){
    observer=new IntersectionObserver(function(entries){
      entries.forEach(function(entry){
        if(entry.isIntersecting && entry.intersectionRatio >= .25){
          showMessage();
          observer.unobserve(section);
        }
      });
    },{threshold:[.25]});
    observer.observe(section);
  }else{
    var fired=false;
    window.addEventListener('scroll',function(){
      if(fired)return;
      var r=section.getBoundingClientRect();
      if(r.top < window.innerHeight*.75 && r.bottom > 0){
        fired=true;
        showMessage();
      }
    },{passive:true});
  }
})();
