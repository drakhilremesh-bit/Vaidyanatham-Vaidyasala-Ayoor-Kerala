/* Extracted from uploaded website; classic script to preserve global onclick handlers. */
(function(){
  'use strict';
  var root=document.documentElement;
  root.classList.add('va-preload');

  function reveal(){
    root.classList.remove('va-preload');
  }

  if(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches){
    reveal();
  }else if(document.readyState==='loading'){
    document.addEventListener('DOMContentLoaded',function(){
      requestAnimationFrame(function(){
        requestAnimationFrame(reveal);
      });
    },{once:true});
  }else{
    requestAnimationFrame(reveal);
  }

  /* Wheel and touch scrolling remain fully native. Existing navigation code
     handles anchor targets and uses smooth programmatic scrolling. */
})();
