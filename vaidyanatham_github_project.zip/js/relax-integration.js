/* Extracted from uploaded website; classic script to preserve global onclick handlers. */
(function(){
  function initFinalPatch(){
    const relax=document.getElementById('vaidyanathamRelax');
    const secondary=document.querySelector('.navSecondary');

    /* Initial position: directly below the Wellness navigation, right side. */
    if(relax){
      relax.style.position='fixed';
      const safeRight=Math.max(10,parseInt(getComputedStyle(document.documentElement).getPropertyValue('--safe-area-inset-right'))||0);
      const navBottom=secondary ? secondary.getBoundingClientRect().bottom : 0;
      const top=Math.max(8,Math.round(navBottom+10));
      relax.style.setProperty('--va-relax-left','auto');
      relax.style.setProperty('--va-relax-right',safeRight+'px');
      relax.style.setProperty('--va-relax-top',top+'px');
      relax.style.setProperty('--va-relax-size','58px');
    }

    /* Disable normal copying/selection/context actions for page content.
       Inputs and editable controls remain usable. */
    document.documentElement.classList.add('va-no-copy');
    document.body.classList.add('va-no-copy');
    const editable=e=>{
      const t=e.target;
      return t && (t.matches('input,textarea,select,[contenteditable="true"]') || t.closest('input,textarea,select,[contenteditable="true"]'));
    };
    document.addEventListener('copy',e=>{if(!editable(e))e.preventDefault();},true);
    document.addEventListener('cut',e=>{if(!editable(e))e.preventDefault();},true);
    document.addEventListener('contextmenu',e=>{if(!editable(e))e.preventDefault();},true);
    document.addEventListener('selectstart',e=>{if(!editable(e))e.preventDefault();},true);
    document.addEventListener('dragstart',e=>{if(!editable(e))e.preventDefault();},true);
    document.addEventListener('keydown',e=>{
      if(editable(e))return;
      const k=(e.key||'').toLowerCase();
      if((e.ctrlKey||e.metaKey) && ['a','c','x'].includes(k))e.preventDefault();
    },true);
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',initFinalPatch,{once:true});
  else initFinalPatch();
})();
