/* Extracted from uploaded website; classic script to preserve global onclick handlers. */
(function(){
  const topBtn=document.getElementById('vaBackTop');
  if(!topBtn)return;
  function update(){topBtn.classList.toggle('show',window.scrollY>260)}
  topBtn.addEventListener('click',function(){
    const target=document.getElementById('top')||document.body;
    target.scrollIntoView({behavior:'smooth',block:'start'});
  });
  window.addEventListener('scroll',update,{passive:true});
  update();
})();
